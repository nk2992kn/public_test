sequenceDiagram
    participant User
    participant View
    participant Controller
    participant Model
    participant PlotStrategy

    User ->> View: Click "Load CSV"
    View ->> Controller: load_csv()
    Controller ->> View: askdirectory()
    View ->> User: Open folder selection dialog
    User ->> View: Select folder
    View ->> Controller: folder_path
    Controller ->> Model: load_folder(folder_path)
    Model ->> Controller: Data loaded
    Controller ->> View: update_csv_path(folder_path)

    User ->> View: Click "Plot CSV"
    View ->> Controller: plot_csv()
    Controller ->> Model: get_combined_data()
    Model ->> Controller: combined_data
    Controller ->> PlotStrategy: plot(tab, combined_data, column)
    PlotStrategy ->> Controller: Plot created

    User ->> View: Click "Create Report"
    View ->> Controller: create_report()
    Controller ->> View: asksaveasfilename()
    View ->> User: Open save file dialog
    User ->> View: Select save location
    View ->> Controller: pdf_path
    Controller ->> PlotStrategy: Save plots to PDF
    PlotStrategy ->> Controller: PDF saved
    Controller ->> View: show_message("Report created")
