import tkinter as tk
from tkinter import ttk, filedialog
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("CSVグラフ表示ソフトウェア")
        
        self.csv_path = tk.StringVar()

        # フレームの作成
        frame = tk.Frame(root)
        frame.pack(side='top', padx=10, pady=10)

        # CSV選択ボタン
        self.load_button = tk.Button(frame, text="CSV選択", command=self.load_csv)
        self.load_button.pack(side='top', pady=5)

        # 選択したCSVファイルのパスを表示するラベル
        self.csv_label = tk.Label(frame, textvariable=self.csv_path)
        self.csv_label.pack(side='top', pady=5)

        # プロットボタン
        self.plot_button = tk.Button(frame, text="プロット", command=self.plot_csv)
        self.plot_button.pack(side='top', pady=5)

    def load_csv(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.csv_path.set(file_path)

    def plot_csv(self):
        if not self.csv_path.get():
            return

        # 新しいウィンドウを作成
        plot_window = tk.Toplevel(self.root)
        plot_window.title("グラフ表示")

        # ノートブックを作成
        notebook = ttk.Notebook(plot_window)
        notebook.pack(expand=True, fill='both')

        # CSVを読み込む
        data = pd.read_csv(self.csv_path.get())
        data['Datetime'] = pd.to_datetime(data['Datetime'])  # Datetime列をdatetime型に変換

        # 各列ごとにタブを作成
        for column in data.columns[1:]:
            tab = ttk.Frame(notebook)
            notebook.add(tab, text=column)
            self.plot_graph(tab, data, column)

    def plot_graph(self, tab, data, column):
        fig, ax = plt.subplots()
        ax.plot(data['Datetime'], data[column])
        ax.set_title(column)
        ax.set_xlabel('Datetime')
        ax.set_ylabel(column)

        canvas = FigureCanvasTkAgg(fig, master=tab)
        canvas.draw()
        canvas.get_tk_widget().pack(side='top', fill='both', expand=True)

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
