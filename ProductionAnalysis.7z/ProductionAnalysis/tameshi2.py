import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.backends.backend_pdf import PdfPages
import os
from abc import ABC, abstractmethod

# Model
class CSVModel:
    def __init__(self):
        self.dataframes = []

    def load_folder(self, folder_path):
        self.dataframes = []
        for file in os.listdir(folder_path):
            if file.endswith(".csv"):
                full_path = os.path.join(folder_path, file)
                df = pd.read_csv(full_path)
                df['Datetime'] = pd.to_datetime(df['Datetime'])
                self.dataframes.append(df)

    def get_combined_data(self):
        if not self.dataframes:
            return pd.DataFrame()
        combined_df = pd.concat(self.dataframes, ignore_index=True)
        return combined_df

# View
class CSVView:
    def __init__(self, root):
        self.root = root
        self.root.title("CSVグラフ表示ソフトウェア")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.geometry("600x160")
        self.root.resizable(False, False)
        
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x_pos = int(screen_width * 0.1)
        y_pos = int(screen_height * 0.1)
        self.root.geometry(f"+{x_pos}+{y_pos}")

        self.csv_paths = tk.StringVar()

        # フレームの作成
        self.frame = tk.Frame(root)
        self.frame.pack(side='left', padx=10, pady=10, anchor='nw')

        # CSV選択ボタンとパスのテキストを横に並べる
        self.path_frame = tk.Frame(self.frame)
        self.path_frame.pack(side='top', fill='x', pady=5)

        self.load_button = tk.Button(self.path_frame, text="CSV選択", width=20)
        self.load_button.grid(row=0, column=0)

        self.csv_label = tk.Label(self.path_frame, textvariable=self.csv_paths, anchor='w', width=40)
        self.csv_label.grid(row=0, column=1, padx=10, sticky='w')

        # ボタンフレームを作成して縦に並べる
        self.button_frame = tk.Frame(self.frame)
        self.button_frame.pack(side='top', fill='x', pady=5)

        self.plot_button = tk.Button(self.button_frame, text="プロット", width=20)
        self.plot_button.grid(row=1, column=0, pady=5, sticky='w')

        self.report_button = tk.Button(self.button_frame, text="レポート作成", width=20)
        self.report_button.grid(row=2, column=0, pady=5, sticky='w')

    def on_closing(self):
        self.root.destroy()

    def update_csv_path(self, path):
        self.csv_paths.set(path)

    def show_message(self, title, message):
        messagebox.showinfo(title, message)

    def show_error(self, title, message):
        messagebox.showerror(title, message)

# Strategy Interface
class PlotStrategy(ABC):
    @abstractmethod
    def plot(self, tab, data, column):
        pass

# Concrete Strategy for Line Plot
class LinePlotStrategy(PlotStrategy):
    def plot(self, tab, data, column):
        fig, ax = plt.subplots()
        ax.plot(data['Datetime'], data[column])
        ax.set_title(column)
        ax.set_xlabel('Datetime')
        ax.set_ylabel(column)

        canvas = FigureCanvasTkAgg(fig, master=tab)
        canvas.draw()
        canvas.get_tk_widget().pack(side='top', fill='both', expand=True)

        def on_key(event):
            if event.key == 'r':
                ax.set_xlim(auto=True)
                ax.set_ylim(auto=True)
                canvas.draw()

        def on_click(event):
            if event.button == 1:
                xlim = ax.get_xlim()
                ylim = ax.get_ylim()
                x_range = (xlim[1] - xlim[0]) * 0.9
                y_range = (ylim[1] - ylim[0]) * 0.9
                ax.set_xlim(event.xdata - x_range / 2, event.xdata + x_range / 2)
                ax.set_ylim(event.ydata - y_range / 2, event.ydata + y_range / 2)
                canvas.draw()
            elif event.button == 3:
                xlim = ax.get_xlim()
                ylim = ax.get_ylim()
                x_range = (xlim[1] - xlim[0]) * 1.1
                y_range = (ylim[1] - ylim[0]) * 1.1
                ax.set_xlim(event.xdata - x_range / 2, event.xdata + x_range / 2)
                ax.set_ylim(event.ydata - y_range / 2, event.ydata + y_range / 2)
                canvas.draw()

        def on_scroll(event):
            xlim = ax.get_xlim()
            ylim = ax.get_ylim()
            x_range = (xlim[1] - xlim[0])
            y_range = (ylim[1] - ylim[0])
            if event.delta > 0:  # Scroll up
                scale_factor = 0.9
            else:  # Scroll down
                scale_factor = 1.1
            ax.set_xlim(event.xdata - (x_range * scale_factor) / 2, event.xdata + (x_range * scale_factor) / 2)
            ax.set_ylim(event.ydata - (y_range * scale_factor) / 2, event.ydata + (y_range * scale_factor) / 2)
            canvas.draw()

        canvas.mpl_connect('key_press_event', on_key)
        canvas.mpl_connect('button_press_event', on_click)
        canvas.mpl_connect('scroll_event', on_scroll)

# Controller
class CSVController:
    def __init__(self, model, view, plot_strategy: PlotStrategy):
        self.model = model
        self.view = view
        self.plot_strategy = plot_strategy

        self.view.load_button.config(command=self.load_csv)
        self.view.plot_button.config(command=self.plot_csv)
        self.view.report_button.config(command=self.create_report)

    def load_csv(self):
        folder_path = filedialog.askdirectory()
        if folder_path:
            self.model.load_folder(folder_path)
            self.view.update_csv_path(folder_path)
        else:
            self.view.show_error("エラー", "フォルダを選択してください")

    def plot_csv(self):
        combined_data = self.model.get_combined_data()
        if combined_data.empty:
            self.view.show_error("エラー", "データがありません")
            return

        self.plot_window = tk.Toplevel(self.view.root)
        self.plot_window.title("グラフ表示")

        self.notebook = ttk.Notebook(self.plot_window)
        self.notebook.pack(expand=True, fill='both')

        self.plots = []

        for column in combined_data.columns[1:]:
            tab = ttk.Frame(self.notebook)
            self.notebook.add(tab, text=column)
            self.plot_strategy.plot(tab, combined_data, column)
            self.plots.append(self.plot_strategy)

    def create_report(self):
        if not hasattr(self, 'plots') or not self.plots:
            self.view.show_error("エラー", "プロットされたグラフがありません")
            return

        pdf_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if pdf_path:
            with PdfPages(pdf_path) as pdf:
                for plot_strategy in self.plots:
                    fig = plot_strategy.fig
                    pdf.savefig(fig)
            self.view.show_message("情報", f"レポートが作成されました: {pdf_path}")

if __name__ == "__main__":
    root = tk.Tk()
    model = CSVModel()
    view = CSVView(root)
    line_plot_strategy = LinePlotStrategy()
    controller = CSVController(model, view, line_plot_strategy)
    root.mainloop()
