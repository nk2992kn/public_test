classDiagram
    CSVModel "1" --> "1" CSVController
    CSVView "1" --> "1" CSVController
    PlotStrategy <|-- LinePlotStrategy

    class CSVModel {
        - List~DataFrame~ dataframes
        + void load_folder(folder_path: str)
        + DataFrame get_combined_data()
    }

    class CSVView {
        - Tk root
        - StringVar csv_paths
        + void update_csv_path(path: str)
        + void show_message(title: str, message: str)
        + void show_error(title: str, message: str)
    }

    class CSVController {
        - CSVModel model
        - CSVView view
        - PlotStrategy plot_strategy
        + void load_csv()
        + void plot_csv()
        + void create_report()
    }

    class PlotStrategy {
        + void plot(tab, data, column)
    }

    class LinePlotStrategy {
        + void plot(tab, data, column)
    }
