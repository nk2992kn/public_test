flowchart TD
    A[Start] --> B[Load CSV Folder]
    B --> C{Folder selected?}
    C -- Yes --> D[Load CSV data into model]
    C -- No --> E[Show error message]
    D --> F[Update CSV path in view]
    F --> G[Plot CSV data]
    G --> H{Data available?}
    H -- Yes --> I[Create new window and plot data]
    H -- No --> J[Show error message]
    I --> K[Create report]
    K --> L[Save report as PDF]
    L --> M[Show success message]
    E --> Z[End]
    J --> Z
    M --> Z[End]
